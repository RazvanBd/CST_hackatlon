import numpy as np
import matplotlib.pyplot as plt

N = 500
temp = None
arr_x = []
arr_y = []
with open('patient.csv','r') as f:
    temp = f.read().split('\n')
    # print(temp)
temp = temp[:-1]
for x in temp :
    arr_x.append(int(x.split(',')[0]))
    arr_y.append(int(x.split(',')[1]))

arr_x2 = []
arr_y2 = []
with open('out31.csv','r') as f:
    temp = f.read().split('\n')
    # print(temp)
temp = temp[:-1]
for x in temp :
    arr_x2.append(int(x.split(',')[0]))
    arr_y2.append(int(x.split(',')[1]))

leg1 = list(zip(arr_x, arr_y))
leg2 = list(zip(arr_x2, arr_y2))

contor = 0
for i, x in enumerate(leg1):
    for j, y in enumerate(leg2):
        if abs(int(x[0]) - int(y[0])) < 25 and abs(int(x[1]) - int(y[1])) < 25 :
            print(f"Close {x} {y}")
            contor += 1
            break

print(contor)
print(len(leg1))

print(float(contor/len(leg1))*100)



