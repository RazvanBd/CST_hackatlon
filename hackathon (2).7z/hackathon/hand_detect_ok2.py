import cv2
import numpy as np
import time

def nothing(x):
    pass

st = []
contor = 0

whole_pos = []
c_csv = 0
is_in_start = False

with open("out.csv", 'r') as traseu:
    temp = traseu.read()
    whole_pos = temp.split('\n')

whole_pos = whole_pos[1:-1]

print(f"whole pos : {whole_pos[0]} type: {type(whole_pos)}")

img = np.zeros((300, 512, 3), np.uint8)
cv2.namedWindow('image')
# create trackbars for color change
cv2.createTrackbar('H_lower', 'image', 0, 255, nothing)
cv2.createTrackbar('S_lower', 'image', 0, 255, nothing)
cv2.createTrackbar('V_lower', 'image', 0, 255, nothing)

cv2.createTrackbar('H_upper', 'image', 0, 255, nothing)
cv2.createTrackbar('S_upper', 'image', 0, 255, nothing)
cv2.createTrackbar('V_upper', 'image', 0, 255, nothing)

lowerBound = np.array([cv2.getTrackbarPos('H_lower', 'image'), 50, 60])
# upperBound=np.array([10,80,80])

# cv2.getTrackbarPos('H_lower','image')
print(cv2.getTrackbarPos('H_lower', 'image'))
# upperBound=np.array([10,80,80])


cam = cv2.VideoCapture(0)
kernelOpen = np.ones((5, 5))
kernelClose = np.ones((20, 20))

font = cv2.FONT_HERSHEY_SIMPLEX
contor = 0
while True:
    ret, img = cam.read()
    img = cv2.resize(img, (400,400))
    img = cv2.flip(img, 1)
    cv2.imshow('image', img)


    lowerBound = np.array([cv2.getTrackbarPos('H_lower', 'image'), cv2.getTrackbarPos('S_lower', 'image'),
                           cv2.getTrackbarPos('V_lower', 'image')])
    upperBound = np.array([cv2.getTrackbarPos('H_upper', 'image'), cv2.getTrackbarPos('S_upper', 'image'),
                           cv2.getTrackbarPos('V_upper', 'image')])

    lowerBound = np.array([70, 85, 114])
    upperBound = np.array([120, 255, 255])
    #
    lowerBound2 = np.array([61, 66, 77])
    upperBound2 = np.array([161, 255, 255])

    imgHSV = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)

    mask = cv2.inRange(imgHSV, lowerBound, upperBound)
    mask2 = cv2.inRange(imgHSV, lowerBound2, upperBound2)
    # mask2 = cv2.inRange(imgHSV, lowerBound, upperBound)

    maskOpen = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernelOpen)
    maskClose = cv2.morphologyEx(maskOpen, cv2.MORPH_CLOSE, kernelClose)
    maskFinal = maskClose
    conts, h = cv2.findContours(maskFinal.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)

    maskOpen2 = cv2.morphologyEx(mask2, cv2.MORPH_OPEN, kernelOpen)
    maskClose2 = cv2.morphologyEx(maskOpen2, cv2.MORPH_CLOSE, kernelClose)
    maskFinal2 = maskClose2
    conts2, h2 = cv2.findContours(maskFinal2.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)

    (major_ver, minor_ver, subminor_ver) = (cv2.__version__).split('.')

    if int(major_ver) < 3:
        fps = cam.get(cv2.cv.CV_CAP_PROP_FPS)
        # print ("Frames per second using video.get(cv2.cv.CV_CAP_PROP_FPS): {0}".format(fps))
    else:
        fps = cam.get(cv2.CAP_PROP_FPS)
        # print ("Frames per second using video.get(cv2.CAP_PROP_FPS) : {0}".format(fps))

    # img = cv2.circle(img, (100, 400), 20, (255, 0, 0), 3)

    # contor += fps
    # if contor % 300 :
    #     cv2.circle(img, (100, int(contor/30)), 25, (0, 255, 0))


    contor += fps
    if contor % 300 and is_in_start == True:
        print(f"C_csv : {c_csv}")
        c_csv += 1
        try:
            print(f"whole pos : {whole_pos[c_csv].split(',')[0]}")
            pos_x = int(whole_pos[c_csv].split(',')[0])
            pos_y = int(whole_pos[c_csv].split(',')[1])
            width = int(whole_pos[c_csv].split(',')[2])
            height = int(whole_pos[c_csv].split(',')[3])

        except:
            cam.release()
            cv2.destroyAllWindows()
            with open("patient.csv", 'w') as f:
                for x in st:
                    f.write(x + '\n')
            break
            # c_csv = 0
        if pos_x == 0 and pos_y == 0:
            cv2.circle(img, (pos_x, pos_y), 20, (255, 0, 0), 3)
        elif pos_y == 0:
            cv2.circle(img, (pos_x - width, pos_y), 20, (255, 0, 0), 3)
        elif pos_x == 0 :
            cv2.circle(img, (pos_x, pos_y - height), 20, (255, 0, 0), 3)
        else:
            cv2.circle(img, (int(pos_x-width/2), int(pos_y-height/2+76*2)), 20, (255, 0, 0), 3)
        # cv2.circle(img, (pos_x-width, pos_y-height), 20, (255, 0, 0), 3)
        # cv2.rectangle(img, (pos_x, pos_y), 25, (0, 255, 0))

        # cv2.rectangle(img, (pos_x-30, pos_y-30), (pos_x, pos_y), (0, 0, 255), 2)

    cv2.drawContours(img, conts, -1, (255, 0, 0), 3)
    cv2.drawContours(img, conts2, -1, (255, 0, 0), 3)

    for i in range(len(conts)):
        x, y, w, h = cv2.boundingRect(conts[i])
        if (w * h) > 4500:
            cv2.rectangle(img, (x, y), (x + w, y + h), (0, 0, 255), 2)
            current_point = cv2.rectangle(img, (x, y), (x + w, y + h), (0, 0, 255), 2)
            if is_in_start == False :
                pos_x = int(whole_pos[0].split(',')[0])
                pos_y = int(whole_pos[0].split(',')[1])
                width = int(whole_pos[0].split(',')[2])
                height = int(whole_pos[0].split(',')[3])
                if pos_x == 0 and pos_y == 0:
                    start_point = cv2.circle(img, (pos_x, pos_y), 40, (255, 0, 0), 3)
                elif pos_y == 0:
                    start_point = cv2.circle(img, (pos_x - width, pos_y), 40, (255, 0, 0), 3)
                    pos_x -= width
                elif pos_x == 0:
                    start_point = cv2.circle(img, (pos_x, pos_y - height), 40, (255, 0, 0), 3)
                    pos_y-=height
                else:
                    start_point = cv2.circle(img, (int(pos_x - width / 2), int(pos_y - height / 2 + 76 * 2)), 40, (255, 0, 0), 3)
                    pos_x = int(pos_x - width / 2)
                    pos_y = int(pos_y - height / 2 + 76 * 2)
                print(f"x: {x} y: {y} x_start: {pos_x+width} y_start: {pos_y}")
                if x - pos_x+width == 0 and y - pos_y:
                    print("Intersectat")
                    is_in_start = True
            if is_in_start == True:
                st.append(f"{x},{y},{w},{h}")
    # cv2.cv.PutText(cv2.cv.fromarray(img), str(i+1),(x,y+h),font,(0,255,255))
    cv2.imshow("maskClose", maskClose)
    cv2.imshow("maskOpen", maskOpen)
    cv2.imshow("mask", mask)


    for i in range(len(conts2)):
        x, y, w, h = cv2.boundingRect(conts2[i])
        if (w * h) > 4500:
            cv2.rectangle(img, (x, y), (x + w, y + h), (0, 255, 0), 2)
            st.append(f"{x},{y},{w},{h}")
    # cv2.cv.PutText(cv2.cv.fromarray(img), str(i+1),(x,y+h),font,(0,255,255))
    cv2.imshow("maskClose2", maskClose2)
    cv2.imshow("maskOpen2", maskOpen2)
    cv2.imshow("mask2", mask2)

    cv2.imshow("cam", img)
    # cv2.waitKey(10)
    k = cv2.waitKey(1)

    if k % 256 == 27:
        # ESC pressed
        print("Escape hit, closing...")
        cam.release()
        cv2.destroyAllWindows()
        with open("patient.csv",'w') as f:
            for x in st:
                f.write(x + '\n')
        break


