import numpy as np
import matplotlib.pyplot as plt

temp = None
arr_x = []
arr_y = []
with open('out20.csv','r') as f:
    temp = f.read().split('\n')
    print(temp)
temp = temp[:-1]
for x in temp :
    arr_x.append(int(x.split(',')[0]))
    arr_y.append(int(x.split(',')[1]))

area = np.pi*3
plt.scatter(arr_x, arr_y, s=area, c='red', alpha=0.5)
plt.plot(arr_x, arr_y, '.r')
plt.title('Scatter plot :')
plt.xlabel('x')
plt.ylabel('y')
plt.show()
# plt.savefig('temp.png')