import cv2
import numpy as np


def nothing(x):
    pass

img = np.zeros((300, 512, 3), np.uint8)
cv2.namedWindow('image')
# create trackbars for color change
cv2.createTrackbar('H_lower', 'image', 0, 255, nothing)
cv2.createTrackbar('S_lower', 'image', 0, 255, nothing)
cv2.createTrackbar('V_lower', 'image', 0, 255, nothing)

cv2.createTrackbar('H_upper', 'image', 0, 255, nothing)
cv2.createTrackbar('S_upper', 'image', 0, 255, nothing)
cv2.createTrackbar('V_upper', 'image', 0, 255, nothing)

lowerBound = np.array([cv2.getTrackbarPos('H_lower', 'image'), 50, 60])
# upperBound=np.array([10,80,80])

# cv2.getTrackbarPos('H_lower','image')
print(cv2.getTrackbarPos('H_lower', 'image'))
# upperBound=np.array([10,80,80])


cam = cv2.VideoCapture(0)
# cam.set(CV2_CAP_PROP_FPS, 10);
kernelOpen = np.ones((5, 5))
kernelClose = np.ones((20, 20))

# font=cv2.cv.InitFont(cv2.cv.CV_FONT_HERSHEY_SIMPLEX,2,0.5,0,3,1)
# font=cv2.cv.InitFont(cv2.CV_FONT_HERSHEY_SIMPLEX,2,0.5,0,3,1)
font = cv2.FONT_HERSHEY_SIMPLEX
while True:
    ret, img = cam.read()
    img = cv2.resize(img, (640, 420))
    cv2.imshow('image', img)
    lowerBound = np.array([70, 85, 114])
    upperBound = np.array([120, 255, 255])

    # lowerBound = np.array([cv2.getTrackbarPos('H_lower', 'image'), cv2.getTrackbarPos('S_lower', 'image'),
    #                        cv2.getTrackbarPos('V_lower', 'image')])
    #
    # upperBound = np.array([cv2.getTrackbarPos('H_upper', 'image'), cv2.getTrackbarPos('S_upper', 'image'),
    #                        cv2.getTrackbarPos('V_upper', 'image')])

    # upperBound=np.array([70,80,116])
    # lowerBound=np.array([100,255,255])

    ##fps = cam.get(cv2.cv.CV_CAP_PROP_FPS)
    ##print ("Frames per second using video.get(cv2.cv.CV_CAP_PROP_FPS): {0}".format(fps))

    # convert BGR to HSV
    imgHSV = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    # create the Mask
    mask = cv2.inRange(imgHSV, lowerBound, upperBound)
    # morphology
    maskOpen = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernelOpen)
    maskClose = cv2.morphologyEx(maskOpen, cv2.MORPH_CLOSE, kernelClose)

    maskFinal = maskClose
    conts, h = cv2.findContours(maskFinal.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)

    cv2.drawContours(img, conts, -1, (255, 0, 0), 3)
    for i in range(len(conts)):
        x, y, w, h = cv2.boundingRect(conts[i])
        if (w * h) > 4500:
            cv2.rectangle(img, (x, y), (x + w, y + h), (0, 0, 255), 2)
        # print(str(x) + "," + str(y))
        print(f"x{x}\t{y}\t{w}\t{h}")
    # cv2.cv.PutText(cv2.cv.fromarray(img), str(i+1),(x,y+h),font,(0,255,255))
    cv2.imshow("maskClose", maskClose)
    cv2.imshow("maskOpen", maskOpen)
    cv2.imshow("mask", mask)
    cv2.imshow("cam", img)
    # cv2.waitKey(10)
    k = cv2.waitKey(1)
    #
    if k % 256 == 27:
        # ESC pressed
        print("Escape hit, closing...")
        cam.release()
        cv2.destroyAllWindows()
        break
