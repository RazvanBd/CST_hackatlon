whole_pos = []
with open("out.csv", 'r') as traseu:
    temp = traseu.read()
    whole_pos = temp.split('\n')

print(whole_pos)