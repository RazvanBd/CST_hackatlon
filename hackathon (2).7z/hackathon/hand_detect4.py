import cv2
import numpy as np


def nothing(x):
    pass


st = []
contor = 0

whole_pos = []
c_csv = 0
is_in_start = False

with open("out20.csv", 'r') as traseu:
    temp = traseu.read()
    whole_pos = temp.split('\n')

whole_pos = whole_pos[1:-1]

print(f"whole pos : {whole_pos[0]} type: {type(whole_pos)}")

img = np.zeros((300, 512, 3), np.uint8)
cv2.namedWindow('image')

lowerBound = np.array([cv2.getTrackbarPos('H_lower', 'image'), 50, 60])

cam = cv2.VideoCapture(0)
kernelOpen = np.ones((5, 5))
kernelClose = np.ones((20, 20))

contor = 0
while True:
    ret, img = cam.read()
    img = cv2.resize(img, (800, 600))
    img = cv2.flip(img, 1)
    cv2.imshow('image', img)

    lowerBound = np.array([70, 80, 116])
    upperBound = np.array([100, 255, 255])

    imgHSV = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)

    mask = cv2.inRange(imgHSV, lowerBound, upperBound)

    maskOpen = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernelOpen)
    maskClose = cv2.morphologyEx(maskOpen, cv2.MORPH_CLOSE, kernelClose)

    maskFinal = maskClose
    conts, h = cv2.findContours(maskFinal.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)

    fps = cv2.CAP_PROP_FPS
    fps += 25
    contor += fps
    for cc in range(len(whole_pos)):
        pos_x = int(whole_pos[cc].split(',')[0])
        pos_y = int(whole_pos[cc].split(',')[1])
        width = int(whole_pos[cc].split(',')[2])
        height = int(whole_pos[cc].split(',')[3])
        cv2.rectangle(img, (pos_x, pos_y), (pos_x + 10, pos_y + 10), (0, 0, 255), 2)

    if contor % 300 and is_in_start == True:
        c_csv += 1
        try:
            pos_x = int(whole_pos[c_csv].split(',')[0])
            pos_y = int(whole_pos[c_csv].split(',')[1])
            width = int(whole_pos[c_csv].split(',')[2])
            height = int(whole_pos[c_csv].split(',')[3])
            cv2.rectangle(img, (pos_x-25, pos_y-25), (pos_x + 25, pos_y + 25), (0, 0, 255), 2)

        except:
            # cam.release()
            # cv2.destroyAllWindows()
            # with open("patient.csv", 'w') as f:
            #     for x in st:
            #         f.write(x + '\n')
            # # break
            c_csv = 0

            # cv2.circle(img, (pos_x-width, pos_y-height), 20, (255, 0, 0), 3)
            # cv2.rectangle(img, (pos_x, pos_y), 25, (0, 255, 0))
        cv2.rectangle(img, (pos_x, pos_y), (pos_x + 15, pos_y + 16), (255, 255, 0), 2)

        # cv2.rectangle(img, (pos_x-30, pos_y-30), (pos_x, pos_y), (0, 0, 255), 2)

    cv2.drawContours(img, conts, -1, (255, 0, 0), 3)
    for i in range(len(conts)):
        x, y, w, h = cv2.boundingRect(conts[i])
        if (w * h) > 1500:
            cv2.rectangle(img, (x, y), (x + w, y + h), (0, 0, 255), 2)
            # current_point = cv2.rectangle(img, (x, y), (x + w, y + h), (0, 0, 255), 2)
            if is_in_start == False:
                pos_x = int(whole_pos[0].split(',')[0])
                pos_y = int(whole_pos[0].split(',')[1])
                width = int(whole_pos[0].split(',')[2])
                height = int(whole_pos[0].split(',')[3])

                cv2.rectangle(img, (pos_x, pos_y), (pos_x + 10, pos_y + 10), (0, 0, 255), 2)

                # start_point = cv2.circle(img, (int(pos_x + width / 2), int(pos_y + height / 2 + 76 * 2)), 20, (255, 0, 0), 3)

                print(f"x: {x} y: {y} x_start: {pos_x} y_start: {pos_y}")
            if pos_x <= x + w and pos_x - width > x and pos_y + (height / 2) > y and pos_y <= y + h:
                print("Intersectat")
                is_in_start = True
            if is_in_start == True:
                st.append(f"{x},{y},{w},{h}")
            cv2.circle(img, (x, y), 5, (0, 0, 255), -1)
            cv2.circle(img, (x + w, y + h), 5, (0, 255, 0), -1)
            cv2.circle(img, (pos_x + 1, pos_y + 1), 5, (0, 255, 0), -1)
            cv2.circle(img, (pos_x, pos_y), 5, (255, 0, 0), -1)

            cv2.rectangle(img, (pos_x, pos_y), (pos_x + 10, pos_y + 10), (0, 0, 255), 2)

    # cv2.cv.PutText(cv2.cv.fromarray(img), str(i+1),(x,y+h),font,(0,255,255))
    cv2.imshow("maskClose", maskClose)
    cv2.imshow("maskOpen", maskOpen)
    cv2.imshow("mask", mask)
    cv2.imshow("cam", img)
    # cv2.waitKey(10)
    k = cv2.waitKey(1)

    if k % 256 == 27:
        # ESC pressed
        print("Escape hit, closing...")
        cam.release()
        cv2.destroyAllWindows()
        with open("patient.csv", 'w') as f:
            for x in st:
                f.write(x + '\n')
        break