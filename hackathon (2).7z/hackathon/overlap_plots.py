import numpy as np
import matplotlib.pyplot as plt

temp = None
arr_x = []
arr_y = []
with open('patient.csv','r') as f:
    temp = f.read().split('\n')
    print(temp)
temp = temp[:-1]
for x in temp :
    arr_x.append(int(x.split(',')[0]))
    arr_y.append(int(x.split(',')[1]))

temp2 = None
arr_x2 = []
arr_y2 = []
with open('patient.csv','r') as f:
    temp2 = f.read().split('\n')
    print(temp2)
temp2 = temp2[1:-1]
for x in temp2 :
    arr_x2.append(int(x.split(',')[0])+25)
    arr_y2.append(int(x.split(',')[1])+25)


area = np.pi*3
plt.scatter(arr_x, arr_y, s=area, c='red', alpha=0.5)
plt.plot(arr_x, arr_y, '.r')
plt.scatter(arr_x2, arr_y2, s=area, c='blue', alpha=0.5)
# plt.plot(arr_x, arr_y, '.r')
plt.title('Scatter plot :')
plt.xlabel('x')
plt.ylabel('y')
plt.show()
# plt.savefig('temp.png')