import cv2
import numpy as np
import datetime


def nothing(x):
    pass


st = []
contor = 0

img = np.zeros((300, 512, 3), np.uint8)
cv2.namedWindow('image')

lowerBound = np.array([cv2.getTrackbarPos('H_lower', 'image'), 50, 60])

cam = cv2.VideoCapture(0)
kernelOpen = np.ones((5, 5))
kernelClose = np.ones((20, 20))

contor = 0
while True:
    ret, img = cam.read()
    img = cv2.resize(img, (800, 600))
    img = cv2.flip(img, 1)
    cv2.imshow('image', img)

    lowerBound = np.array([70, 80, 116])
    upperBound = np.array([100, 255, 255])

    imgHSV = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)

    mask = cv2.inRange(imgHSV, lowerBound, upperBound)

    maskOpen = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernelOpen)
    maskClose = cv2.morphologyEx(maskOpen, cv2.MORPH_CLOSE, kernelClose)

    maskFinal = maskClose
    conts, h = cv2.findContours(maskFinal.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)

    cv2.drawContours(img, conts, -1, (255, 0, 0), 3)
    for i in range(len(conts)):
        x, y, w, h = cv2.boundingRect(conts[i])
        if (w * h) > 1000:
            cv2.rectangle(img, (x, y), (x + w, y + h), (0, 0, 255), 2)
            print(f"x: {x} y: {y}")
            st.append(f"{x},{y},{w},{h}")

    # cv2.cv.PutText(cv2.cv.fromarray(img), str(i+1),(x,y+h),font,(0,255,255))
    cv2.imshow("maskClose", maskClose)
    cv2.imshow("maskOpen", maskOpen)
    cv2.imshow("mask", mask)
    cv2.imshow("cam", img)
    # cv2.waitKey(10)
    k = cv2.waitKey(1)

    if k % 256 == 27:
        # ESC pressed
        print("Escape hit, closing...")
        cam.release()
        cv2.destroyAllWindows()
        with open("out" + str(datetime.datetime.now().time())[3:5] + ".csv", 'w') as f:
            for x in st:
                f.write(x + '\n')
        break